﻿using MidProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Final.Login
{
    public partial class SignIn : Form
    {
        public SignIn()
        {
            InitializeComponent();
        }


        public static string Log_IN(string username, string password)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT UserRole FROM Customer WHERE UserName = @username AND UserPassword = @password", con);

            cmd.Parameters.AddWithValue("@username", username);
            cmd.Parameters.AddWithValue("@password", password);

            // Assuming 'role' is the column name where the role is stored.
            object result = cmd.ExecuteScalar();

            if (result != null)
                return result.ToString(); // Returning role if found.
            else
                return ""; // Or return some default value if no role found.
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        public void ResetValues()
        {
            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
          

        }
        private void button2_Click(object sender, EventArgs e)
        {
            ResetValues();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            SignUp signup = new SignUp();
            signup.ShowDialog();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox2.Text; // Corrected to textBox2.Text

            string role = Log_IN(username, password);

            if (role.Equals("Admin"))
            {
                this.Hide();
                Admin_Form admin_Form = new Admin_Form();
                admin_Form.ShowDialog();
            }
            else if (role.Equals("Customer"))
            {
                this.Hide();
                Customer_Form customer_Form = new Customer_Form(username);
                customer_Form.ShowDialog();
            }
            else
            {
                MessageBox.Show("Invalid username or password");
            }
        }
    }
}
