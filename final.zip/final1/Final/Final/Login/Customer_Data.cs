﻿using MidProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final.Login
{
    public partial class Customer_Data : Form
    {
        string username;
        string password;
        string role;
        public Customer_Data(string username, string password, string role)
        {
            InitializeComponent();
            this.username = username;
            this.password = password;   
            this.role = role;
        }

        public static void AddUSer(string first_name, string last_name, string gender, string address, string contact_email, string country, string region, string username, string password, string role)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Insert into Customer values (@first_name, @last_name,@gender,@address,@contact_email,@country,@region,@username,@password,@role)", con);

            cmd.Parameters.AddWithValue("@first_name", first_name);
            cmd.Parameters.AddWithValue("@last_name", last_name);
            cmd.Parameters.AddWithValue("@gender", gender);
            cmd.Parameters.AddWithValue("@address", address);
            cmd.Parameters.AddWithValue("@contact_email", contact_email);
            cmd.Parameters.AddWithValue("@country", country);
            cmd.Parameters.AddWithValue("@region", region);
            cmd.Parameters.AddWithValue("@username", username);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.Parameters.AddWithValue("@role", role);


            cmd.ExecuteNonQuery();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string first_name = textBox1.Text;
            string last_name = textBox2.Text;
            string gender = textBox3.Text;
            string address = textBox4.Text;
            string contact_email = textBox5.Text;   
            string country = textBox6.Text;
            string region = textBox7.Text;
            AddUSer(first_name, last_name, gender, address, contact_email, country, region,username,password,role);
            MessageBox.Show("Added Successfully");
            this.Close();

        }

        private void Customer_Data_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
