﻿using Final.Cart;
using Final.Products;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final
{
    public partial class Customer_Form : Form
    {
        string username;
        public Customer_Form(string username)
        {
            InitializeComponent();
            this.username = username;
        }

        private void Customer_Form_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();   
        }

        private void AddPanel(UserControl usercontrol)
        {
            usercontrol.Dock = DockStyle.Fill;
            panel8.Controls.Clear();
            panel8.Controls.Add(usercontrol);
            usercontrol.BringToFront();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string username1 = username;
            Add_Cart cart_Menue = new Add_Cart(username1);
            AddPanel(cart_Menue);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Feed_Back feeback_Menue = new Feed_Back();
            AddPanel(feeback_Menue);
        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
