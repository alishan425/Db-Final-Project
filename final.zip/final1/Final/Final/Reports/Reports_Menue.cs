﻿using iTextSharp.text;
using MidProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final.Reports
{
    public partial class Reports_Menue : UserControl
    {
        public Reports_Menue()
        {
            InitializeComponent();
        }

        private void CreatePdfFromDataTable(string title, DataTable dataTable)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "PDF files (.pdf)|.pdf";
            saveFileDialog.Title = "Export to PDF";
            saveFileDialog.FileName = title;
            saveFileDialog.ShowDialog();

            if (saveFileDialog.FileName != "")
            {
                Document document = new Document(PageSize.A4, 10f, 10f, 10f, 10f);
                iTextSharp.text.pdf.PdfWriter.GetInstance(document, new FileStream(saveFileDialog.FileName, FileMode.Create));
                document.Open();
                Paragraph heading1 = new Paragraph("University of Engineering & Technology, Lahore", FontFactory.GetFont("Arial", 20));
                heading1.Alignment = Element.ALIGN_CENTER;
                document.Add(heading1);
                document.Add(new iTextSharp.text.Chunk("\n"));

                Paragraph heading2 = new Paragraph("Department of Computer Science", FontFactory.GetFont("Arial", 20));
                heading2.Alignment = Element.ALIGN_CENTER;
                document.Add(heading2);
                document.Add(new iTextSharp.text.Chunk("\n"));

                Paragraph heading = new Paragraph(title, FontFactory.GetFont("Arial", 20));
                heading.Alignment = Element.ALIGN_CENTER;
                document.Add(heading);
                document.Add(new iTextSharp.text.Chunk("\n"));

                iTextSharp.text.pdf.PdfPTable pdfTable = new iTextSharp.text.pdf.PdfPTable(dataTable.Columns.Count);
                pdfTable.DefaultCell.Padding = 3;
                pdfTable.WidthPercentage = 105;
                pdfTable.HorizontalAlignment = Element.ALIGN_LEFT;

                foreach (DataColumn column in dataTable.Columns)
                {
                    iTextSharp.text.pdf.PdfPCell cell = new iTextSharp.text.pdf.PdfPCell(new Phrase(column.ColumnName));
                    pdfTable.AddCell(cell);
                }

                foreach (DataRow row in dataTable.Rows)
                {
                    foreach (var item in row.ItemArray)
                    {
                        string cellText = item != null ? item.ToString() : "";
                        pdfTable.AddCell(cellText);
                    }
                }

                document.Add(pdfTable);

                document.Close();

                MessageBox.Show("PDF file has been created!");
            }
        }

        DataTable Get_All_Products()
        {
            DataTable product = new DataTable();
            product.Columns.Add("Product_ModelName.");
            product.Columns.Add("Product_Category");
            product.Columns.Add("Product_Size");
            product.Columns.Add("Product_Price");
            string q = "Select product.Product_ModelName, product.Product_Category, product.Product_Size, product.Product_Price from product";

            SqlCommand sqlcmd1 = new SqlCommand(q, Configuration.getInstance().getConnection());
            SqlDataReader dr = sqlcmd1.ExecuteReader();
            while (dr.Read())
            {
                product.Rows.Add(dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString());
            }

            return product;
        }

        DataTable Get_All_Customers()
        {
            DataTable customer = new DataTable();
            customer.Columns.Add("Customer_FirstName.");
            customer.Columns.Add("Customer_LastName");
            customer.Columns.Add("Customer_Gender");
            customer.Columns.Add("Customer_Address");
            customer.Columns.Add("Customer_ContactEmail");
            string q = "Select Customer.Customer_FirstName, Customer.Customer_LastName, Customer.Customer_Gender, Customer.Customer_Address, Customer.Customer_ContactEmail from Customer";

            SqlCommand sqlcmd1 = new SqlCommand(q, Configuration.getInstance().getConnection());
            SqlDataReader dr = sqlcmd1.ExecuteReader();
            while (dr.Read())
            {
                customer.Rows.Add(dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString());
            }

            return customer;
        }

        DataTable get_sales()
        {
            DataTable bill = new DataTable();
            //bill.Columns.Add("ProductId.");
            bill.Columns.Add("Product_ModelName");
            bill.Columns.Add("Order_Id");
            bill.Columns.Add("Customer Name");
            bill.Columns.Add("Quantity");
            bill.Columns.Add("UnitPrice");
            bill.Columns.Add("Total Price");
            bill.Columns.Add("Date");



            string q = "Select  product.Product_ModelName, OrderDetail.OrderId,Customer.Customer_FirstName, OrderDetail.Quantity, OrderDetail.UnitPrice, OrderDetail.TotalPrice, OrderDetail.Date From OrderDetail inner join product on product.ProductId = Orderdetail.ProductId inner join orders on orders.OrderId = Orderdetail.OrderId inner join Customer on Customer.CustomerId = orders.OrderId";

            SqlCommand sqlcmd1 = new SqlCommand(q, Configuration.getInstance().getConnection());
            SqlDataReader dr = sqlcmd1.ExecuteReader();
            while (dr.Read())
            {
                bill.Rows.Add(dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString(), dr[6].ToString());
            }

            return bill;
        }
        private void button3_Click(object sender, EventArgs e)
        {
            CreatePdfFromDataTable("Products", Get_All_Products());
        }

        private void button2_Click(object sender, EventArgs e)
        {
         
           CreatePdfFromDataTable("Customers", Get_All_Customers());
            
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            CreatePdfFromDataTable("Sales and Transaction Report", get_sales());
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
