﻿using MidProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final.Cart
{
    public partial class UpdateProductForm : Form
    {
        public string ProductID, OrderID, Quantity, unitprice;
        public UpdateProductForm(string ProductID, string OrderID, string Quantity, string unitprice)
        {
            InitializeComponent();
            this.ProductID = ProductID;
            this.OrderID = OrderID;
            this.Quantity = Quantity;
            this.unitprice = unitprice;
            lblOrderID.Text = OrderID;
            lblProductID.Text = ProductID;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // update
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Update Orderdetail set Quantity = @quantity, TotalPrice = @totalprice where ProductID = @productid and OrderID = @orderid", con);
            cmd.Parameters.AddWithValue("@quantity", textBox3.Text);
            int quantity = int.Parse(textBox3.Text);
            int Price = int.Parse(unitprice.ToString()); 
            cmd.Parameters.AddWithValue("@totalprice", quantity * Price);
            cmd.Parameters.AddWithValue("@productid", ProductID);
            cmd.Parameters.AddWithValue("@orderid", OrderID);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Quantity updated successfully");
        }
    }
}
