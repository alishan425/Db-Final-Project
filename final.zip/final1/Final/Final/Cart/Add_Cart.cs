﻿using MidProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Final.Cart
{
    public partial class Add_Cart : UserControl
    {
        public int index = -1;
        string username;
        public Add_Cart(string username)
        {
            this.username = username;
            InitializeComponent();
            Populate_Product_Table();
            PopulateCartTable();
            // AddColumn(dataGridView2);
        }

        /*private void addPanel(UserControl usercontrol)
        {
            usercontrol.Dock = DockStyle.Fill;
            panel2.Controls.Clear();
            panel2.Controls.Add(usercontrol);
            usercontrol.BringToFront();

        }*/

        public static SqlCommand View_Products()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from product", con);
            return cmd;
        }

        public void PopulateCartTable()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd1 = new SqlCommand("Select CustomerID From Customer where UserName = @username", con);
            cmd1.Parameters.AddWithValue("@username", username);
            object result = cmd1.ExecuteScalar();
            string customerID = result != null ? result.ToString() : null;

            SqlCommand cmd = new SqlCommand("Select OrderDetail.ProductId, product.Product_ModelName, OrderDetail.OrderId, OrderDetail.Quantity, OrderDetail.UnitPrice, OrderDetail.TotalPrice From OrderDetail inner join product on product.ProductId = Orderdetail.ProductId inner join [Orders] on [Orders].OrderID = Orderdetail.OrderID inner join Customer on Customer.CustomerID = [Orders].CustomerID where [Orders].CustomerID = @custID ", con);
            cmd.Parameters.AddWithValue("@custID", customerID);
            cmd.ExecuteNonQuery();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            gridCart.DataSource = dt;
        }

        private void Populate_Product_Table()
        {
            SqlCommand cmd = View_Products();
            cmd.ExecuteNonQuery();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            gridProducts.DataSource = dt;
            //dataGridView1.Columns[0].Visible = false;
        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        public void TransferRows(DataGridView dataGridView1, DataGridView dataGridView2)
        {
            foreach (DataGridViewRow row in dataGridView1.SelectedRows)
            {
                // Clone the row from the source grid
                DataGridViewRow clonedRow = (DataGridViewRow)row.Clone();
                foreach (DataGridViewCell cell in row.Cells)
                {
                    clonedRow.Cells[cell.ColumnIndex].Value = cell.Value;
                }

                // Add the cloned row to the destination grid
                dataGridView2.Rows.Add(clonedRow);
            }
        }

        public void AddColumn(DataGridView grid)
        {
           
            DataGridViewTextBoxColumn column1 = new DataGridViewTextBoxColumn();
            column1.HeaderText = "Product_ModelName";
            column1.Name = "Product_ModelName";

            DataGridViewTextBoxColumn column2 = new DataGridViewTextBoxColumn();
            column2.HeaderText = "Product_Category";
            column2.Name = "Product_Category";

            DataGridViewTextBoxColumn column3 = new DataGridViewTextBoxColumn();
            column3.HeaderText = "Product_Size";
            column3.Name = "Product_Size";

            DataGridViewTextBoxColumn column4 = new DataGridViewTextBoxColumn();
            column4.HeaderText = "Product_Price";
            column4.Name = "Product_Price";

            DataGridViewTextBoxColumn column5 = new DataGridViewTextBoxColumn();
            column5.HeaderText = "Total_Price";
            column5.Name = "Total_Price";

          
            grid.Columns.Add(column1);
            grid.Columns.Add(column2);
            grid.Columns.Add(column3);
            grid.Columns.Add(column4);
            grid.Columns.Add(column5);
        }

        public void CopySelectedRowWithShift(DataGridView sourceGrid, DataGridView destinationGrid)
        {
            // Check if any row is selected in the source grid
            if (sourceGrid.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a row to copy.");
                return;
            }

            // Get the selected row
            DataGridViewRow selectedRow = sourceGrid.SelectedRows[0];

            // Create a new row for the destination grid
            DataGridViewRow newRow = (DataGridViewRow)selectedRow.Clone();

            // Copy the cell values from the selected row to the new row with a shift
            for (int i = 0; i < selectedRow.Cells.Count; i++)
            {
                if (i == 0)
                {
                    // Skip copying the first cell's value
                    continue;
                }

                // Copy the value from the previous cell
                newRow.Cells[i - 1].Value = selectedRow.Cells[i].Value;
            }

            // Add the new row to the destination grid
            destinationGrid.Rows.Add(newRow);
        }


     /*   public void CopySelectedRowToAnotherGrid(DataGridView dataGridView1, DataGridView dataGridView2)
        {
            // Check if any row is selected in the source grid
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a row to copy.");
                return;
            }

            // Get the selected row
            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

            // Create a new row for the destination grid
            DataGridViewRow newRow = (DataGridViewRow)selectedRow.Clone();

            // Copy the cell values from the selected row to the new row
            for (int i = 0; i < selectedRow.Cells.Count; i++)
            {
                newRow.Cells[i].Value = selectedRow.Cells[i].Value;
            }

            // Add the new row to the destination grid
            dataGridView2.Rows.Add(newRow);
        }
*/
        private void Add_Cart_Load(object sender, EventArgs e)
        {
            //label2.Visible = false;
            //textBox1.Visible = false;   

        }
        

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            // CopyColumns(dataGridView1, dataGridView2);
          
            //label2.Visible = true;
            //textBox1.Visible = true;
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
           
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            //CopySelectedRowWithShift(dataGridView1, dataGridView2);
          // TransferAndMultiply(dataGridView1, dataGridView2, label1.Text);
            
            
            
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            // addpan;
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void gridProducts_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // click on products table
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            // add cart button
            if(gridProducts.SelectedRows.Count > 0) 
            {
                string quantity = txtquantity.Text;
                string ProductID = gridProducts.SelectedRows[0].Cells[0].Value.ToString();
               // string ProductID = gridProducts.SelectedRows[0].Cells[0].Value.ToString();
                string price = gridProducts.SelectedRows[0].Cells[4].Value.ToString();
                int p = int.Parse(price.ToString());
                int q = int.Parse(quantity.ToString());
                int CalculatedPrice = p * q;
                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Select CustomerID From Customer where UserName = @username",con);
                cmd.Parameters.AddWithValue("@username", username);
                object result = cmd.ExecuteScalar();
                string customerID = result != null ? result.ToString() : null;

                // Insert data in OrderID
                SqlCommand InOrderTable = new SqlCommand("Insert into Orders values (@customerID, @OrderDate)", con);
                InOrderTable.Parameters.AddWithValue("@customerID", customerID);
                InOrderTable.Parameters.AddWithValue("@OrderDate", DateTime.Now);
                InOrderTable.ExecuteNonQuery();

                // select maxID from Orders
                SqlCommand maxID = new SqlCommand("Select max(OrderId) From Orders", con);
                int id = (int)maxID.ExecuteScalar();

                SqlCommand InsertInOrderDetail = new SqlCommand("Insert into Orderdetail values (@ProductID,@OrderID, @Quantity, @UnitPrice, @TotalPrice, @date)", con);
                InsertInOrderDetail.Parameters.AddWithValue("@ProductID",ProductID);
                InsertInOrderDetail.Parameters.AddWithValue("@OrderID",id);
                InsertInOrderDetail.Parameters.AddWithValue("@Quantity",txtquantity.Text);
                InsertInOrderDetail.Parameters.AddWithValue("@UnitPrice",price);
                InsertInOrderDetail.Parameters.AddWithValue("@TotalPrice",CalculatedPrice);
                InsertInOrderDetail.Parameters.AddWithValue("@date", "-" );
                InsertInOrderDetail.ExecuteNonQuery();
                MessageBox.Show("Product added successfully");
                PopulateCartTable();
            }
        }

        private void gridCart_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            // delete 
            if(gridCart.SelectedRows.Count > 0) 
            {
                string ProductID = gridCart.SelectedRows[0].Cells[0].Value.ToString();
                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Delete From Orderdetail where ProductId = @productid", con);
                cmd.Parameters.AddWithValue("@productid", ProductID);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Product deleted successfully");
                PopulateCartTable();
            }
        }

        private void btnChangeQuantity_Click(object sender, EventArgs e)
        {
            // change quantity 
            if (gridCart.SelectedRows.Count > 0)
            {
                string ProductID = gridCart.SelectedRows[0].Cells[0].Value.ToString();
                string OrderID = gridCart.SelectedRows[0].Cells[1].Value.ToString();
                string quantity = gridCart.SelectedRows[0].Cells[2].Value.ToString();
                string unitPrice = gridCart.SelectedRows[0].Cells[4].Value.ToString();
                UpdateProductForm up = new UpdateProductForm(ProductID, OrderID, quantity,unitPrice);
                up.ShowDialog();
                PopulateCartTable();
            }
        }

        private void btnClearCart_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Delete From Orderdetail", con);
            cmd.ExecuteNonQuery();
            PopulateCartTable();
        }

        private void btnCalculateBill_Click(object sender, EventArgs e)
        {
            calc_bill c_bill = new calc_bill(username);
            c_bill.ShowDialog();
            
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
