﻿using iTextSharp.text;
using MidProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final.Cart
{
    public partial class calc_bill : Form
    {
        string username;
        public calc_bill(string username)
        {
            InitializeComponent();

            this.username = username;
            label4.Text = username;
            PopulateCartTable();
            total_sum_bill();
        }

        private void calc_bill_Load(object sender, EventArgs e)
        {

        }

        public void PopulateCartTable()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd1 = new SqlCommand("Select CustomerID From Customer where UserName = @username", con);
            cmd1.Parameters.AddWithValue("@username", username);
            object result = cmd1.ExecuteScalar();
            string customerID = result != null ? result.ToString() : null;

            SqlCommand cmd = new SqlCommand("Select OrderDetail.ProductId, product.Product_ModelName, OrderDetail.OrderId, OrderDetail.Quantity, OrderDetail.UnitPrice, OrderDetail.TotalPrice From OrderDetail inner join product on product.ProductId = Orderdetail.ProductId inner join [Orders] on [Orders].OrderID = Orderdetail.OrderID inner join Customer on Customer.CustomerID = [Orders].CustomerID where [Orders].CustomerID = @custID ", con);
            cmd.Parameters.AddWithValue("@custID", customerID);
            cmd.ExecuteNonQuery();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void CreatePdfFromDataTable(string title, DataTable dataTable, string label_text)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "PDF files (.pdf)|.pdf";
            saveFileDialog.Title = "Export to PDF";
            saveFileDialog.FileName = title;
            saveFileDialog.ShowDialog();

            if (saveFileDialog.FileName != "")
            {
                Document document = new Document(PageSize.A4, 10f, 10f, 10f, 10f);
                iTextSharp.text.pdf.PdfWriter.GetInstance(document, new FileStream(saveFileDialog.FileName, FileMode.Create));
                document.Open();
                Paragraph heading1 = new Paragraph("University of Engineering & Technology, Lahore", FontFactory.GetFont("Arial", 20));
                heading1.Alignment = Element.ALIGN_CENTER;
                document.Add(heading1);
                document.Add(new iTextSharp.text.Chunk("\n"));

                Paragraph heading2 = new Paragraph("Department of Computer Science", FontFactory.GetFont("Arial", 20));
                heading2.Alignment = Element.ALIGN_CENTER;
                document.Add(heading2);
                document.Add(new iTextSharp.text.Chunk("\n"));

                Paragraph heading = new Paragraph(title, FontFactory.GetFont("Arial", 20));
                heading.Alignment = Element.ALIGN_CENTER;
                document.Add(heading);
                document.Add(new iTextSharp.text.Chunk("\n"));

                Paragraph heading0 = new Paragraph("Customer Name: "+label_text, FontFactory.GetFont("Arial", 20));
                heading.Alignment = Element.ALIGN_LEFT;
                document.Add(heading0);
                document.Add(new iTextSharp.text.Chunk("\n"));

                iTextSharp.text.pdf.PdfPTable pdfTable = new iTextSharp.text.pdf.PdfPTable(dataTable.Columns.Count);
                pdfTable.DefaultCell.Padding = 3;
                pdfTable.WidthPercentage = 105;
                pdfTable.HorizontalAlignment = Element.ALIGN_LEFT;

                foreach (DataColumn column in dataTable.Columns)
                {
                    iTextSharp.text.pdf.PdfPCell cell = new iTextSharp.text.pdf.PdfPCell(new Phrase(column.ColumnName));
                    pdfTable.AddCell(cell);
                }

                foreach (DataRow row in dataTable.Rows)
                {
                    foreach (var item in row.ItemArray)
                    {
                        string cellText = item != null ? item.ToString() : "";
                        pdfTable.AddCell(cellText);
                    }
                }
                document.Add(pdfTable);

                // query
              //  SqlCommand cmd = new SqlCommand("Select CustomerID From Customer where Customer_FirstName = @")


                Paragraph heading_0 = new Paragraph("Total Price: "+ label6.Text, FontFactory.GetFont("Arial", 20));
                heading.Alignment = Element.ALIGN_LEFT;
                document.Add(heading_0);
                document.Add(new iTextSharp.text.Chunk("\n"));

                document.Close();

                MessageBox.Show("PDF file has been created!");
            }
        }

        public void  total_sum_bill()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT SUM(Orderdetail.TotalPrice) AS TotalSum " +
                                            "FROM Customer " +
                                            "JOIN Orders ON Customer.CustomerId = Orders.CustomerId " +
                                            "JOIN Orderdetail ON Orders.OrderId = Orderdetail.OrderId " +
                                            "JOIN Product ON Product.ProductId = Orderdetail.ProductId ", con);
            object totalSum = cmd.ExecuteScalar();
            if (totalSum != DBNull.Value)
            {
                label6.Text = Convert.ToDecimal(totalSum).ToString();
            }
            else
            {
               
            }

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        DataTable get_bill()
        {
            DataTable bill = new DataTable();
            //bill.Columns.Add("ProductId.");
            bill.Columns.Add("ProductId");
            bill.Columns.Add("Product_ModelName");
            bill.Columns.Add("OrderId");
            bill.Columns.Add("Quantity");
            bill.Columns.Add("UnitPrice");
            bill.Columns.Add("Total Price");


            // string q =   "Select  product.Product_ModelName, OrderDetail.OrderId, OrderDetail.Quantity, OrderDetail.UnitPrice, OrderDetail.TotalPrice From OrderDetail inner join product on product.ProductId = Orderdetail.ProductId";
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd1 = new SqlCommand("Select CustomerID From Customer where UserName = @username", con);
            cmd1.Parameters.AddWithValue("@username", username);
            object result = cmd1.ExecuteScalar();
            string customerID = result != null ? result.ToString() : null;

            string q = "Select OrderDetail.ProductId, product.Product_ModelName, OrderDetail.OrderId, OrderDetail.Quantity, OrderDetail.UnitPrice, OrderDetail.TotalPrice From OrderDetail inner join product on product.ProductId = Orderdetail.ProductId inner join [Orders] on [Orders].OrderID = Orderdetail.OrderID inner join Customer on Customer.CustomerID = [Orders].CustomerID where [Orders].CustomerID = @custID";

            SqlCommand sqlcmd1 = new SqlCommand(q, Configuration.getInstance().getConnection());
            sqlcmd1.Parameters.AddWithValue("@custID", customerID); // Make sure to add this line to assign the parameter to the correct command
            SqlDataReader dr = sqlcmd1.ExecuteReader();

            while (dr.Read())
            {
                bill.Rows.Add(dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(),dr[5].ToString());
            }

            return bill;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            CreatePdfFromDataTable("CustomerBill", get_bill(), username);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // pay 
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd1 = new SqlCommand("Select CustomerID From Customer where UserName = @username", con);
            cmd1.Parameters.AddWithValue("@username", username);
            object result = cmd1.ExecuteScalar();
            string customerID = result != null ? result.ToString() : null;

            SqlCommand cmd = new SqlCommand("Update OrderDetail set OrderDetail.Date = @date From Orderdetail inner join Orders on Orders.OrderId = Orderdetail.OrderId inner join Customer on Customer.CustomerID = Orders.CustomerID where Orders.CustomerID = @custID", con);
            cmd.Parameters.AddWithValue("@date", DateTime.Now);
            cmd.Parameters.AddWithValue("@custID", customerID);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Bill Paid successfully");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
