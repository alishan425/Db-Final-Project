﻿using iTextSharp.text;
using MidProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final.Cart
{    
    public partial class Calculate_Bill : UserControl
    {
        string username;
        public Calculate_Bill(string username)
        {
            InitializeComponent();
            PopulateCartTable();
            this.username = username;
            label4.Text = username;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        public void PopulateCartTable()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select ProductId, OrderId, Quantity, UnitPrice, TotalPrice From OrderDetail", con);
            cmd.ExecuteNonQuery();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
       

        private void CreatePdfFromDataTable(string title, DataTable dataTable)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "PDF files (.pdf)|.pdf";
            saveFileDialog.Title = "Export to PDF";
            saveFileDialog.FileName = title;
            saveFileDialog.ShowDialog();

            if (saveFileDialog.FileName != "")
            {
                Document document = new Document(PageSize.A4, 10f, 10f, 10f, 10f);
                iTextSharp.text.pdf.PdfWriter.GetInstance(document, new FileStream(saveFileDialog.FileName, FileMode.Create));
                document.Open();
                Paragraph heading1 = new Paragraph("University of Engineering & Technology, Lahore", FontFactory.GetFont("Arial", 20));
                heading1.Alignment = Element.ALIGN_CENTER;
                document.Add(heading1);
                document.Add(new iTextSharp.text.Chunk("\n"));

                Paragraph heading2 = new Paragraph("Department of Computer Science", FontFactory.GetFont("Arial", 20));
                heading2.Alignment = Element.ALIGN_CENTER;
                document.Add(heading2);
                document.Add(new iTextSharp.text.Chunk("\n"));

                Paragraph heading = new Paragraph(title, FontFactory.GetFont("Arial", 20));
                heading.Alignment = Element.ALIGN_CENTER;
                document.Add(heading);
                document.Add(new iTextSharp.text.Chunk("\n"));

                iTextSharp.text.pdf.PdfPTable pdfTable = new iTextSharp.text.pdf.PdfPTable(dataTable.Columns.Count);
                pdfTable.DefaultCell.Padding = 3;
                pdfTable.WidthPercentage = 105;
                pdfTable.HorizontalAlignment = Element.ALIGN_LEFT;

                foreach (DataColumn column in dataTable.Columns)
                {
                    iTextSharp.text.pdf.PdfPCell cell = new iTextSharp.text.pdf.PdfPCell(new Phrase(column.ColumnName));
                    pdfTable.AddCell(cell);
                }

                foreach (DataRow row in dataTable.Rows)
                {
                    foreach (var item in row.ItemArray)
                    {
                        string cellText = item != null ? item.ToString() : "";
                        pdfTable.AddCell(cellText);
                    }
                }

                document.Add(pdfTable);

                document.Close();

                MessageBox.Show("PDF file has been created!");
            }
        }


        DataTable Get_All_Products()
        {
            DataTable product = new DataTable();
            product.Columns.Add("Product_ModelName.");
            product.Columns.Add("Product_Category");
            product.Columns.Add("Product_Size");
            product.Columns.Add("Product_Price");
            string q = "Select product.Product_ModelName, product.Product_Category, product.Product_Size, product.Product_Price from product";

            SqlCommand sqlcmd1 = new SqlCommand(q, Configuration.getInstance().getConnection());
            SqlDataReader dr = sqlcmd1.ExecuteReader();
            while (dr.Read())
            {
                product.Rows.Add(dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString());
            }

            return product;
        }

        private void label4_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Calculate_Bill_Load(object sender, EventArgs e)
        {

        }
    }
}
