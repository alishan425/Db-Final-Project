﻿using MidProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final.Products
{
    public partial class Update_Product : UserControl
    {
        public Update_Product()
        {
            InitializeComponent();
            Populate_Product_Table();
        }

        public static SqlCommand View_Products()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from product", con);
            return cmd;
        }
        private void Populate_Product_Table()
        {
            SqlCommand cmd = View_Products();
            cmd.ExecuteNonQuery();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].Visible = false;
        }

        public static void Update_Product_Information(string idvalue , string Product_ModelName, string Product_Category, string Product_Size, string Product_Price)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand Updatecmd = new SqlCommand("Update product Set Product_ModelName = @Product_ModelName, Product_Category = @Product_Category, Product_Size = @Product_Size where product.ProductId = @idvalue", con);
           

  
            Updatecmd.Parameters.AddWithValue("@Product_ModelName", Product_ModelName);
            Updatecmd.Parameters.AddWithValue("@Product_Category", Product_Category);
            Updatecmd.Parameters.AddWithValue("@Product_Size", Product_Size);
            Updatecmd.Parameters.AddWithValue("@Product_Price", Product_Price);
            Updatecmd.Parameters.AddWithValue("@idvalue", idvalue);
            Updatecmd.ExecuteNonQuery();
            
        }


        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void maskedTextBox3_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            string Product_ModelName = textBox1.Text;
            string Product_Category = comboBox2.Text;
            string Product_Size = comboBox1.Text;
            string Product_Price = textBox2.Text;
           

            if (dataGridView1.SelectedRows.Count > 0)
            {

                string idvalue = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                Update_Product_Information(idvalue, Product_ModelName, Product_Category, Product_Size, Product_Price);
                MessageBox.Show("Product Updated Successfully");
                Populate_Product_Table();
            }
            else
            {
                MessageBox.Show("Please Select Row First");
            }
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                textBox1.Text = selectedRow.Cells["Product_ModelName"].Value.ToString();
                comboBox2.Text = selectedRow.Cells["Product_Category"].Value.ToString();
                comboBox1.Text = selectedRow.Cells["Product_Size"].Value.ToString();
                textBox2.Text = selectedRow.Cells["Product_Price"].Value.ToString();
       
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
