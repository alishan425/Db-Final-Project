﻿using MidProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final.Products
{
    public partial class Add_Product : UserControl
    {
        public Add_Product()
        {
            InitializeComponent();
        }

        public static void AddProduct(string Product_ModelName, string Product_Category, string Product_Size, string Product_Price)
        {
            try
            {
                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Insert into product values (@Product_ModelName, @Product_Category,@Product_Size, @Product_Price)", con);

                cmd.Parameters.AddWithValue("@Product_ModelName", Product_ModelName);
                cmd.Parameters.AddWithValue("@Product_Category", Product_Category);
                cmd.Parameters.AddWithValue("@Product_Size", Product_Size);
                cmd.Parameters.AddWithValue("@Product_Price", Product_Price);
                cmd.ExecuteNonQuery();
            }
            catch (SqlException e)
            {
                MessageBox.Show(e.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string Product_ModelName = textBox1.Text;
            string Product_Category = comboBox2.Text;
            string Product_Size = comboBox1.Text;
            string Product_Price = textBox2.Text;
           

            AddProduct(Product_ModelName, Product_Category, Product_Size, Product_Price);

            MessageBox.Show("Product Added Successfully");
            ClearTextBoxes();

        }

        private void ClearTextBoxes()
        {
            textBox1.Text = string.Empty;
             comboBox2.Text = string.Empty;
            comboBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
           
           
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void maskedTextBox3_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
